class EntropyCalculator {
  constructor() {
    this.data = [];
    this.tableData = {
      attributes: [],
      instances: [],
      errors: 0,
      missing: 0
    };
    
    this.initElements();
    this.bindEvents();
  }
  
  initElements() {
    this.elements = {
      table: document.querySelector('table'),
      codeContainer: document.getElementById('data-table'),
      loadButton: document.getElementById('loadBtn'),
      EnteropyButton: document.getElementById('alculate-btn'),
      fileInput: document.getElementById('fileInput'),
      progressBar: $('#progress'),
      classAttributeSelect: $('#class-attribute'),
      resultDisplay: document.getElementById("result"),
      missingDataDisplay: document.getElementById("missing-data"),
      errorsDisplay: document.getElementById("errors")
    };
  }
  
  bindEvents() {
    this.elements.loadButton.addEventListener('click', () => this.handleFileUpload());
    this.elements.EnteropyButton.addEventListener('click', () => this.calculateEntropy());
  }
  
  handleFileUpload() {
    const file = this.elements.fileInput.files[0];
    if (!file) {
      alert('Please upload a file.');
      return;
    }
    
    const reader = new FileReader();
    reader.onload = (e) => this.processExcelFile(e);
    reader.readAsArrayBuffer(file);
  }
  
  processExcelFile(e) {
    const data = new Uint8Array(e.target.result);
    const workbook = XLSX.read(data, { type: 'array' });
    const firstSheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[firstSheetName];
    const jsonOutput = XLSX.utils.sheet_to_json(worksheet, { header: 1 });
    
    this.data = JSON.parse(JSON.stringify(jsonOutput, null, 2));
    this.renderTable();
  }
  
  renderTable() {
    this.clearTable();
    this.createTableHeader();
    this.createTableBody();
    this.processDataAttributes();
    this.populateClassAttributeDropdown();
  }
  
  clearTable() {
    this.elements.codeContainer.innerText = '';
    this.tableData.errors = 0;
    this.elements.table.innerHTML = '';
  }
  
  createTableHeader() {
    let headerHtml = '<thead><th scope="col">#</th>';
    this.tableData.attributes = [];
    
    this.data[0].forEach((attribute, index) => {
      this.tableData.attributes.push(attribute);
      headerHtml += `<th scope="col">${attribute}</th>`;
    });
    
    headerHtml += '</thead>';
    this.elements.table.innerHTML = headerHtml;
  }
  
  createTableBody() {
    const width = 100 / this.data.length;
    this.tableData.instances = [];
    
    this.data.slice(1).forEach((row, i) => {
      setTimeout(() => {
        let rowHtml = `<tr><td>${i + 1}</td>`;
        this.tableData.instances.push(row);
        
        row.forEach(cell => {
          rowHtml += `<td>${cell}</td>`;
        });
        
        rowHtml += '</tr>';
        this.elements.table.innerHTML += rowHtml;
        
        const progress = Math.trunc(width * (i + 2));
        this.elements.progressBar
          .html(`${progress}%`)
          .css('width', `${progress}%`);
      }, 0);
    });
  }
  
  processDataAttributes() {
    this.tableData.attributes.forEach((attr, i) => {
      const rowValues = this.data.slice(1).map(row => {
        const cellValue = row[i];
        
        // Handle missing data
        if (cellValue === '' || cellValue === null || cellValue === '?') {
          row[i] = '?';
          this.tableData.missing++;
        }
        if (cellValue === 'NULL') {
          this.tableData.errors++;
        }
        return row[i];
      });
      
      this.tableData.attributes[i] = {
        name: attr,
        labels: this.removeDuplicates(rowValues)
      };
    });

    this.elements.missingDataDisplay.innerHTML = `عدد البيانات المفقودة: ${this.tableData.missing}`;
    this.elements.errorsDisplay.innerHTML = `عدد الأخطاء: ${this.tableData.errors}`;
  }
  
  
  populateClassAttributeDropdown() {
    this.elements.classAttributeSelect.empty();
    
    this.tableData.attributes.forEach(attr => {
      this.elements.classAttributeSelect.append(
        `<option value="${attr.name}">${attr.name}</option>`
      );
    });
  }
  
  calculateEntropy() {
    const classAttribute = this.elements.classAttributeSelect.val();
    const classIndex = this.tableData.attributes.findIndex(attr => attr.name === classAttribute);
    
    if (classIndex === -1) {
      this.elements.resultDisplay.textContent = "Please select a valid class attribute.";
      return;
    }
    
    const labelCounts = this.countClassLabels(classIndex);
    const total = Object.values(labelCounts).reduce((sum, count) => sum + count, 0);
    
    if (total === 0) {
      this.elements.resultDisplay.textContent = "لا توجد بيانات صالحة للحساب";
      return;
    }
    
    const entropy = this.computeEntropy(labelCounts, total);
    this.displayResult(entropy, labelCounts);
  }
  
  countClassLabels(classIndex) {
    const labelCounts = {};
    
    this.tableData.instances.forEach(instance => {
      const label = instance[classIndex];
      labelCounts[label] = (labelCounts[label] || 0) + 1;
    });
    
    return labelCounts;
  }
  
  computeEntropy(labelCounts, total) {
    let entropy = 0;
    
    for (const label in labelCounts) {
      const probability = labelCounts[label] / total;
      if (probability > 0) {
        entropy += -probability * this.log2(probability);
      }
    }
    
    return Math.round(entropy * 1000) / 1000;
  }
  
  displayResult(entropy, labelCounts) {
    let resultHTML = `
      <h3>نتائج حساب الإنتروبي</h3>
      <p><strong>الإنتروبي:</strong> ${entropy.toFixed(3)}</p>
      <h4>توزيع القيم:</h4>
      <ul>
    `;
    
    for (const label in labelCounts) {
      const percentage = (labelCounts[label] / Object.values(labelCounts).reduce((a, b) => a + b, 0) * 100).toFixed(1);
      resultHTML += `<li>${label}: ${labelCounts[label]} (${percentage}%)</li>`;
    }
    
    resultHTML += '</ul>';
    this.elements.resultDisplay.innerHTML = resultHTML;
  }
  
  removeDuplicates(array) {
    return array.reduce((acc, current) => {
      if (!acc.includes(current)) {
        acc.push(current);
      }
      return acc;
    }, []);
  }
  
  log2(x) {
    return Math.log(x) / Math.log(2);
  }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
  window.entropyCalculator = new EntropyCalculator();
});