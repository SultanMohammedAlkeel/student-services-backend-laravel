let mydata = []
let table = document.querySelector('table')
let code = document.getElementById('data-table')
let value = document.querySelector('.value')

let data = {};
let p1, p2 = 0;
let errors = 0;
document.getElementById('loadBtn').addEventListener('click', function () {
  const fileInput = document.getElementById('fileInput')
  const file = fileInput.files[0]

  if (!file) {
    alert('Please upload a file.')
    return
  }

  const reader = new FileReader()
  reader.onload = function (e) {
    const data = new Uint8Array(e.target.result)
    const workbook = XLSX.read(data, {
      type: 'array'
    })

    const firstSheetName = workbook.SheetNames[0]
    const worksheet = workbook.Sheets[firstSheetName]

    const jsonOutput = XLSX.utils.sheet_to_json(worksheet, {
      header: 1
    })
    mydata = JSON.parse(JSON.stringify(jsonOutput, null, 2))
  }
  reader.readAsArrayBuffer(file)
  loadTable();
})

function loadTable () {
  code.innerText = ''
  let tr = ''
  let td = ''

  let width = 100 / +mydata.length
  let th = '<thead>'
  th += `<th scope="col">#</th>`
  let attributes = []
  for (let i = 0; i < mydata[0].length; i++) {
    attributes.push(mydata[0][i])
    th += `<th scope="col">${mydata[0][i]}</th>`
  }
  
  data.attributes =  attributes;
  th += '</thead>'
  table.innerHTML = th
  let instances = []
  for (let i = 1; i < mydata.length; i++) {
    setTimeout(() => {
      td = ''
      tr = '<tr>'
      td += `<td>${i}</td>`
      instances.push(mydata[i])
      for (let j = 0; j < mydata[i].length; j++) {
        td += `<td>${mydata[i][j]}</td>`
      }
      tr += td
      tr += '</tr>'
      table.innerHTML += tr
      $('#progress').html(Math.trunc(width * (i + 1)) + '%')
      $('#progress').css('width', Math.trunc(width * (i + 1)) + '%')
    }, 0)
  }

  data.data = instances

  let row = [];
  $('#class-attribute').empty()
  data.attributes.forEach(element => {
      $('#class-attribute').append(`<option value="${element}">${element}</option>`)
  });
  for (let i = 0; i < data.attributes.length; i++) {
      for (let j = 1; j < mydata.length; j++) {
        if (mydata[j][i] === '') {
          mydata[j][i] = 'NULL';
          errors++;
        }
        if (mydata[j][i] === null) {
          mydata[j][i] = 'NULL'
          errors++;
        }
        if (mydata[j][i] === '?') {
          mydata[j][i] = 'NULL'
          errors++;
        }
          row.push(mydata[j][i]);
        }
        data.attributes[i] = {
          'name': data.attributes[i],
          'labels': removeDuplicates(row)
        }
        row = [];
  }
  alert('الاخطاء: ' + errors + '')
}

function removeDuplicates(array) {
  return array.reduce((acc, current) => {
    if (!acc.includes(current)) {
      acc.push(current);
    }
    return acc;
  }, []);
}


function calculateEntropy() {
  let classAttribute = $('#class-attribute').val();
  let classIndex = data.attributes.findIndex(attr => attr.name === classAttribute);
  let labelCounts = {};
  let totalCount = 0;
  
  for (let i = 0; i < data.data.length; i++) {
    const label = data.data[i][classIndex];
    if (labelCounts[label]) {
      labelCounts[label]++;
    } else {
      labelCounts[label] = 1;
    }
    totalCount++;
  }
  p1 = labelCounts[data.attributes[classIndex].labels[0]];
  p2 = labelCounts[data.attributes[classIndex].labels[1]];
  console.log(p1, p2);
  
  const total = +p1 + +p2;

  if (isNaN(p1) || isNaN(p2) || total === 0) {
    document.getElementById("result").textContent = "يرجى إدخال قيم صالحة.";
    return;
  }

  const prob1 = p1 / total;
  const prob2 = p2 / total;

  let entropy = 0;
  if (prob1 > 0) entropy += -prob1 * log2(prob1);
  if (prob2 > 0) entropy += -prob2 * log2(prob2);

  const roundedEntropy = Math.round(entropy * 1000) / 1000;

  document.getElementById("result").textContent = "الـ Entropy = " + roundedEntropy.toFixed(3);
}

function log2(x) {
  return Math.log(x) / Math.log(2);
}