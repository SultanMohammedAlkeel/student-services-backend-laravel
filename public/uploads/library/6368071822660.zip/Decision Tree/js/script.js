$(document).ready(function () {
    let manufacturers = {};
    let importers = {};

    manufacturer.forEach(function(item) {
      manufacturers[item.id] = item.name;
    });

    // تحميل المستوردين
    importer.forEach(function(item) {
      importers[item.id] = item.name;
    });

    // تحميل الأدوية وعرضها
    let tableBody = $("#content");
    tableBody.empty(); // Clear the table body before appending new rows
    medicines.forEach(function(med) {
      let row = `
        <div class="col-lg-6 col-md-6 col-12">
          <div class="single-news">
              <div class="news-body">
                  <div class="news-content">
                      <h2 class="text-right">
                          <a href="#">${med.name} - (${med.form})</a>
                      </h2>
                      <div class="rtl-layout">
                          <p>${med.name_en}</p>
                          <p>${med.composition} - ${med.strength}</p>
                          <p>السعر: <span class="text-info h6">${med.price}</span> ريال</p>
                      </div>
                      <div class="news-meta rtl-layout">
                          <ul>
                              <li><i class="fa fa-building"></i> <a href="#">${manufacturers[med.manufacturer_id]}</a></li>
                              <li><i class="fa fa-building"></i> <a href="#">${importers[med.importer_id]}</a></li>
                          </ul>
                      </div>
                      <div class="text-left mt-3">
                          <button class=" rounded-circle p-1 mx-1 bg-castom text-dark" onclick="ShowMedicine('${med.id}')">
                          <i class="fa fa-eye"></i>
                          </button>
                          <button class="rounded-circle p-1 mx-1 bg-castom text-dark" onclick="showSameType('${med.composition}')">
                              <i class="fa fa-link"></i>
                          </button>
                          <button class="rounded-circle p-1 mx-1 bg-castom text-dark">
                              <i class="fa fa-bookmark"></i>
                          </button>
                          <button class="rounded-circle p-1 mx-1 bg-castom text-dark" onclick="ShowManufacturer('${med.manufacturer_id}')">
                              <i class="fa fa-building"></i>
                          </button>
                      </div>
                  </div>
              </div>
          </div>
      </div>
      `;
      tableBody.append(row);
    });

});

function showSameType(composition) {

    let manufacturers = {};
    let importers = {};

    manufacturer.forEach(function(item) {
        manufacturers[item.id] = item.name;
    });
  
      // تحميل المستوردين
    importer.forEach(function(item) {
        importers[item.id] = item.name;
    });
// تحميل الأدوية وعرضها
    let tableBody = $("#content");
    tableBody.empty(); // Clear the table body before appending new rows

    medicines.forEach(function(med) {
        if (composition === med.composition) {
            let row = `
            <div class="col-lg-6 col-md-6 col-12">
                <div class="single-news">
                    <div class="news-body">
                        <div class="news-content">
                            <h2 class="text-right">
                                <a href="#">${med.name} - (${med.form})</a>
                            </h2>
                            <div class="rtl-layout">
                                <p>${med.name_en}</p>
                                <p>${med.composition} - ${med.strength}</p>
                                <p>السعر: <span class="text-info h6">${med.price}</span> ريال</p>
                            </div>
                            <div class="news-meta rtl-layout">
                                <ul>
                                    <li><i class="fa fa-building"></i> <a href="#">${manufacturers[med.manufacturer_id]}</a></li>
                                    <li><i class="fa fa-building"></i> <a href="#">${importers[med.importer_id]}</a></li>
                                </ul>
                            </div>
                            <div class="text-left mt-3">
                                <button class="rounded-circle p-1 mx-1 bg-castom text-dark" onclick="ShowMedicine('${med.id}')">
                                <i class="fa fa-eye"></i>
                                </button>
                                <button class="rounded-circle p-1 mx-1 bg-castom text-dark" onclick="showSameType(${med.id})">
                                    <i class="fa fa-link"></i>
                                </button>
                                <button class="rounded-circle p-1 mx-1 bg-castom text-dark">
                                    <i class="fa fa-bookmark"></i>
                                </button>
                                <button class="rounded-circle p-1 mx-1 bg-castom text-dark" onclick="ShowManufacturer('${med.manufacturer_id}')">
                                    <i class="fa fa-building"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            `;
            tableBody.append(row);
            
        }
    });
}


function search(val) {

    let manufacturers = {};
    let importers = {};


    manufacturer.forEach(function(item) {
        manufacturers[item.id] = item.name;
    });
  
      // تحميل المستوردين
    importer.forEach(function(item) {
        importers[item.id] = item.name;
    });
// تحميل الأدوية وعرضها
    let tableBody = $("#content");
    tableBody.empty(); // Clear the table body before appending new rows

    medicines.forEach(function(med) {
        if (med.name.includes(val) || med.name_en.includes(val) || med.composition.includes(val) || med.strength.includes(val)) {
            let row = `
            <div class="col-lg-6 col-md-6 col-12">
                <div class="single-news">
                    <div class="news-body">
                        <div class="news-content">
                            <h2 class="text-right">
                                <a onclick="ShowMedicine('${med.id}')">${med.name} - (${med.form})</a>
                            </h2>
                            <div class="rtl-layout">
                                <p>${med.name_en}</p>
                                <p>${med.composition} - ${med.strength}</p>
                                <p>السعر: <span class="text-info h6">${med.price}</span> ريال</p>
                            </div>
                            <div class="news-meta rtl-layout">
                                <ul>
                                    <li><i class="fa fa-building"></i> <a href="#">${manufacturers[med.manufacturer_id]}</a></li>
                                    <li><i class="fa fa-building"></i> <a href="#">${importers[med.importer_id]}</a></li>
                                </ul>
                            </div>
                            <div class="text-left mt-3">
                                <button class="rounded-circle p-1 mx-1 bg-castom text-dark" onclick="ShowMedicine('${med.id}')">
                                <i class="fa fa-eye"></i>
                                </button>
                                <button class="rounded-circle p-1 mx-1 bg-castom text-dark" onclick="showSameType(${med.id})">
                                    <i class="fa fa-link"></i>
                                </button>
                                <button class="rounded-circle p-1 mx-1 bg-castom text-dark">
                                    <i class="fa fa-bookmark"></i>
                                </button>
                                <button class="rounded-circle p-1 mx-1 bg-castom text-dark" onclick="ShowManufacturer('${med.manufacturer_id}')">
                                    <i class="fa fa-building"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            `;
            tableBody.append(row);
            
        }
    });
}


function ShowMedicine(id) {
    const data = id;
    // ترميز البيانات لتكون آمنة في الرابط
    const encodedData = encodeURIComponent(data);
    window.location.href = `show.html?msg=${encodedData}`;
}

function ShowManufacturer(id) {
    const data = id;
    // ترميز البيانات لتكون آمنة في الرابط
    const encodedData = encodeURIComponent(data);
    window.location.href = `show-medicines.html?msg=${encodedData}`;
}
